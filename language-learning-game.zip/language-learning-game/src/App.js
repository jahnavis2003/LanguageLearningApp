// import logo from './logo.svg';
import './App.css';
import { Routes, Route } from 'react-router-dom';
import HomePage from './components/HomePage';
import RegistrationPage from './components/RegistrationPage';
import ExercisePage from './components/ExercisePage';
import ProfilePage from './components/ProfilePage';
import LoginPage from './components/LoginPage';
import RegisterationConfirmationPage from './components/RegisterationConfirmationPage';
import LeaderBoardPage from './components/LeaderBoardPage';
import GamePage from './components/GamePage';

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/register" element={<RegistrationPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/exercise" element={<ExercisePage />} />
      <Route path="/profile" element={<ProfilePage />} />
      <Route path="/registeration-confirmation" element={<RegisterationConfirmationPage />} />
      <Route path="/leaderboard" element={<LeaderBoardPage />} />
      <Route path="exercise/:selectedLanguage" element={<GamePage />} />
    </Routes>
  );
}

export default App;
