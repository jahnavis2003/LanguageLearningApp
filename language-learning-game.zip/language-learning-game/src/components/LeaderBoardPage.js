import React from 'react';
// import { Link } from 'react-router-dom';
function LeaderBoardPage() {
  return (
    <html>
      <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous"/>
      </head>
      <body className="d-flex justify-content-center align-items-center registeration-confirmation-page">
        <div className='d-flex flex-column justify-content-center align-items-center'>
            <h1>LeaderBoard</h1>
        </div>
      </body>
    </html>
  );
}

export default LeaderBoardPage;