import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';

const GamePage = () => {
  const { selectedLanguage } = useParams();
  const [languageData, setLanguageData] = useState([]); // Initial empty array
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState([]);

  const handleNext = () => {
    setCurrentQuestionIndex((prevIndex) => Math.min(prevIndex + 1, languageData.length - 1));
  };

  const handlePrevious = () => {
    setCurrentQuestionIndex((prevIndex) => Math.max(prevIndex - 1, 0));
  };

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const url = `http://localhost:3090/api/${selectedLanguage}`;
      const response = await fetch(url, { method: 'GET' });
      const data = await response.json();
      setLanguageData(data.message);
      // console.log(data);
      
    } catch (error) {
      setError('Server Error');
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  console.log(languageData);

  return (
    <>
      {error && <p>{error}</p>}
      {isLoading && <p>Loading...</p>}
      {( // Conditional rendering
        <html>
            <head>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous"/>
            </head>
            <body className='game-page'>
                <div className='header'>
                    <h1>A⇆本</h1>
                </div>
                <div className='game-page1'>
                    {currentQuestionIndex < languageData.length && (
                        <div className='questions-card'>
                            {/* <div>
                                <h5>{languageData[currentQuestionIndex].answer}</h5>
                            </div> */}
                            <div>
                                <label>{languageData[currentQuestionIndex].question}</label>
                                {Object.entries(languageData[currentQuestionIndex].options).map(([key, value]) => (
                                    <div key={key} className="form-check options-css">
                                    <input
                                        type="radio"
                                        name={`question-${currentQuestionIndex}`}
                                        className="form-check-input"
                                        value={key}
                                        checked={selectedOptions[currentQuestionIndex] === key}
                                        onChange={() =>
                                        setSelectedOptions((prevOptions) => ({ ...prevOptions, [currentQuestionIndex]: key }))
                                        }
                                    />
                                    <label htmlFor="" className="form-check-label">{value}</label>
                                    </div>
                                ))}
                                <button onClick={handlePrevious} disabled={currentQuestionIndex === 0} className='prev-btn'>
                                    Previous
                                </button>
                                <button onClick={handleNext} disabled={currentQuestionIndex === languageData.length - 1} className='next-btn'>
                                    Next
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </body>
         
        </html>
      )}
    </>
  );
};

export default GamePage;
