import React from 'react';
import { Link } from 'react-router-dom';
function RegistrationPage() {
  return (
    <html>
      <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous"/>
      </head>
      <body >
        <div className="registration-page">
          <div className='header'>
                <h1>A⇆本</h1>
          </div>
          <div className='cya'>
            <div>
              <h1>Create Your Account</h1>
              <form className="details-box">
                <div class="form-group username">
                  <label for="exampleInputUsername1">Username</label>
                  <input type="username" class="form-control" id="exampleInputUsername1" placeholder="Enter Username"/>
                </div>
                <div class="form-group email">
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"/>
                </div>
                <div class="form-group password">
                  <label for="exampleInputPassword1">Password</label>
                  <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password"/>
                </div>
                <button type="submit" className=" registration-create-acc " >
                    <Link className="link" to="/registeration-confirmation">Create Account</Link>
                </button>
              </form>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}

export default RegistrationPage;