import React from 'react';
import { Link } from 'react-router-dom';

function HomePage() {


  return (
    <html>
      <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous"/>
      </head>
      <body>
        <div className="home-page">
          <div className='header'>
            <h1>A⇆本</h1>
            <nav className='buttons'>
              <button className='create-acc'>
                <Link className="link" to="/register">Create Account</Link>
              </button>
              <button className='login'>
                <Link className="link" to="/login">Log In</Link>
              </button>
            </nav>
          </div>
          <div >
            <div className='welcome'>
              <h1>Welcome to language learning game!</h1>
            </div>
            <div className='sub-text'>
              <p>LogIn/Create-Account to continue</p>
            </div>
          </div>
        </div>
      </body>
    </html>
    
  );
}

export default HomePage;
