import React from 'react';
import { Link } from 'react-router-dom';
function LoginPage() {
  return (
      <html>
        <head>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous"/>
        </head>
        <body >
          <div className="registration-page">
            <div className='header'>
                  <h1>A⇆本</h1>
            </div>
            <div className='cya'>
              <div>
                <h1>LogIn</h1>
                <form className="details-box">
                  <div class="form-group email">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"/>
                  </div>
                  <div class="form-group password">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password"/>
                  </div>
                  <div class="form-check checkbox">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                    <label class="form-check-label" for="exampleCheck1">Remember me</label>
                  </div>
                  <button type="submit" class=" login-page-btn" >
                    <Link className="link" to="/profile">Login</Link>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </body>
      </html>
  );
}

export default LoginPage;