import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function ExercisePage() {
  const [selectedLanguage, setSelectedLanguage] = useState('');
  const handleLanguageSelect = (language) => {
    setSelectedLanguage(language);
    // TODO: Handle language selection logic (e.g., store in state or pass as a prop)
  };
  return (
    <html>
      <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous"/>
      </head>
      <body>
        <div  className="exercise-page">
          <div className='header'>
              <h1>A⇆本</h1>
          </div>
          <div className='exercise-page1'>
            <h1>Learning Exercise</h1>
            <div className="language-selection mt-3">
              <label htmlFor="language-select" className="choose-lang">Choose a language:</label>
              <select id="language-select" value={selectedLanguage} onChange={(e) => handleLanguageSelect(e.target.value)}>
                <option value="">Select a language</option>
                <option value="english">English</option>
                <option value="spanish">Spanish</option>
                <option value="french">French</option>
                <option value="japaneese">Japaneese</option>
                {/* Add more languages as needed */}
              </select>
            </div>
            <nav>
              {/* Display "Start Game" link if a language is selected */}
              {selectedLanguage && 
                <button className='start-game'>
                  <Link className="link" to={`/exercise/${selectedLanguage}`}>Start Game</Link>
                </button>
              }
            </nav>
          </div>

          {/* Question presentation and answer input */}
          {/* Feedback on answers */}

        </div>
      </body>
    </html>
  );
}

export default ExercisePage;
