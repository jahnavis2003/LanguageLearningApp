import React from 'react';
import { Link } from 'react-router-dom';
function ProfilePage() {
  return (
    <html>
      <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous"/>
      </head>
      <body className='profile-page'>
        <div className='header'>
          <h1>A⇆本</h1>
        </div>
        <div className=" d-flex flex-column align-items-center justify-content-center profile-box">

          <h1 className=''>Your Profile</h1>
          {/* Progress information */}
          {/* Settings options */}
          <div>
            <button type="submit" class="exercises-btn m-3" >
              <Link className="link p-5 m-5" to="/exercise">Go to Exercises</Link>
            </button>
            <button type="submit" class="exercises-btn m-3" >
              <Link className="link p-5 m-5" to="/leaderboard">Check Leaderboard</Link>
            </button>
          </div>
          
        </div>
      </body>
    </html>
    
  );
}

export default ProfilePage;
